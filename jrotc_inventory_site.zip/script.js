
let inventory = JSON.parse(localStorage.getItem("inventory")) || [
  { name: "Raider ARCs", qty: 20 },
  { name: "PT Belts", qty: 50 },
  { name: "Air Rifles", qty: 12 }
];

let requests = JSON.parse(localStorage.getItem("requests")) || [];

function saveData() {
  localStorage.setItem("inventory", JSON.stringify(inventory));
  localStorage.setItem("requests", JSON.stringify(requests));
}

function renderInventory() {
  const table = document.getElementById("inventoryTable");
  table.innerHTML = "";

  inventory.forEach(item => {
    table.innerHTML += `
      <tr>
        <td>${item.name}</td>
        <td>${item.qty}</td>
      </tr>
    `;
  });
}

function renderRequests() {
  const table = document.getElementById("requestTable");
  table.innerHTML = "";

  requests.forEach((req, index) => {
    table.innerHTML += `
      <tr>
        <td>${req.cadet}</td>
        <td>${req.item}</td>
        <td>${req.qty}</td>
        <td class="${req.status.toLowerCase()}">${req.status}</td>
        <td>
          ${req.status === "Pending" ? `
            <button onclick="approveRequest(${index})">Approve</button>
            <button onclick="denyRequest(${index})">Deny</button>
          ` : ""}
        </td>
      </tr>
    `;
  });
}

function addInventory() {
  const name = document.getElementById("itemName").value;
  const qty = parseInt(document.getElementById("itemQty").value);

  if (!name || !qty) return;

  inventory.push({ name, qty });

  saveData();
  renderInventory();

  document.getElementById("itemName").value = "";
  document.getElementById("itemQty").value = "";
}

function submitRequest() {
  const cadet = document.getElementById("cadetName").value;
  const item = document.getElementById("requestItem").value;
  const qty = parseInt(document.getElementById("requestQty").value);

  if (!cadet || !item || !qty) return;

  requests.push({
    cadet,
    item,
    qty,
    status: "Pending"
  });

  saveData();
  renderRequests();

  document.getElementById("cadetName").value = "";
  document.getElementById("requestItem").value = "";
  document.getElementById("requestQty").value = "";
}

function approveRequest(index) {
  const req = requests[index];
  const invItem = inventory.find(i => i.name === req.item);

  if (!invItem || invItem.qty < req.qty) {
    alert("Not enough inventory.");
    return;
  }

  invItem.qty -= req.qty;
  req.status = "Approved";

  saveData();
  renderInventory();
  renderRequests();
}

function denyRequest(index) {
  requests[index].status = "Denied";

  saveData();
  renderRequests();
}

renderInventory();
renderRequests();
