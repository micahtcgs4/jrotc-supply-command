
# JROTC Military Inventory System

Military-themed inventory and approval tracking system for JROTC units.

## Features
- Admin approval workflow
- Inventory tracking
- Request management
- Military tactical UI
- LocalStorage persistence
- Mobile friendly

## How To Run
1. Download the project
2. Open `index.html` in a browser

## Default Admin
Username: admin
Password: admin123

## Notes
This is a frontend prototype version. 
You can later connect it to Firebase for online multi-user support.
